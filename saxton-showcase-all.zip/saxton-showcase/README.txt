Saxton Showcase, every build, offline

Double-click index.html to open the whole showcase in your browser.
Every game also works on its own: open builds/<name>/index.html.
Each builds/<name>/LEARNED.md is what building it taught Amy, written so
your own AI helper can read it too.

Nothing here needs an install, an account or the internet.
